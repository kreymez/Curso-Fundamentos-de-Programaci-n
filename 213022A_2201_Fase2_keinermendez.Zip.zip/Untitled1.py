print("#****PANADERIA****#")

#Cantidedes de producto
Pan_Frances = int(input("cantidad de panes Frances:"))
pan_de_Queso = int(input("cantidad de panes de Queso:"))
pan_Integral = int(input("cantidad de panes de Integral:"))
Pastel_de_Chocolate = int(input("cantidad de pasteles de Chocolate:"))
Pastel_de_Manzana = int(input("cantidad de pasteles de Manzana:"))

 #TOTAL A PAGAR DE PRODUCTO
Total = (Pan_Frances*3000) + (pan_de_Queso*1000) + (pan_Integral*2000) + (Pastel_de_Chocolate*6000) + (Pastel_de_Manzana*5000)

print("Total sin descuento: $", Total)

#DESCUENTO
if Total > 10000:
    Total = Total - (Total * 0.20)
    print("Se aplicó descuento del 20%")

print("TOTAL A PAGAR", Total)

print("***PRECIO DE PREDUCTOS EN VENTA***")

print("Pan Frances = $3000")
print("Pan de Queso = $1000")
print("Pan Integral = $2000")
print("Pastel de Chocolate = $6000")
print("Pastel de Manzana = $5000")